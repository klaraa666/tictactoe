﻿using System;

namespace TreIRad
{
    class Program
    {

        static void Main(string[] args)
        {
        startx:
            char[] arr = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
            int player = 1;
            int choice;
            int win = 0;



            Console.WriteLine("Player 1: X Player 2: O");
            do
            {
            start:


                if (player == 1)
                {
                    Console.WriteLine($"Player { player}'s turn");
                    Board(arr);
                    choice = int.Parse(Console.ReadLine());
                    Console.Clear();
                    if (arr[choice] != 'X' && arr[choice] != 'O')
                    {
                        arr[choice] = 'X';
                        player++;

                        win = Checkwin(arr);
                        if (win == 1)
                        {
                            if (arr[choice] == 'X')
                            {
                                Console.WriteLine("Congratz player ONE won");
                                //startx resets the code
                                goto startx;
                            }

                        }
                        if (win == -1)
                        {
                            Console.WriteLine("ITS A TIE");
                            //startx resets the code
                            goto startx;
                        }

                    }
                    else
                    {
                        Console.WriteLine("Sorry that spot is already taken :(");
                        goto start;
                    }
                }
                if (player == 2)
                {
                    Console.WriteLine($"Player { player}'s turn");
                    Board(arr);
                    choice = int.Parse(Console.ReadLine());
                    Console.Clear();
                    if (arr[choice] != 'X' && arr[choice] != 'O')
                    {
                        arr[choice] = 'O';
                        player--;

                        win = Checkwin(arr);
                        if (win == 1)
                        {
                            if (arr[choice] == 'O')
                            {
                                Console.WriteLine("Congratz player TWO won");
                                goto startx;
                            }
                        }
                        if (win == -1)
                        {
                            Console.WriteLine("WOW U SUCK");
                            goto startx;
                        }

                    }
                    else
                    {
                        Console.WriteLine("Sorry that spot is already taken :(");
                        goto start;
                    }
                }



            }
            while (win == 0);



            static void Board(char[] sarr)
            {
                Console.WriteLine("     |     |      ");
                Console.WriteLine("  {0}  |  {1}  |  {2}", sarr[1], sarr[2], sarr[3]);
                Console.WriteLine("_____|_____|_____ ");
                Console.WriteLine("     |     |      ");
                Console.WriteLine("  {0}  |  {1}  |  {2}", sarr[4], sarr[5], sarr[6]);
                Console.WriteLine("_____|_____|_____ ");
                Console.WriteLine("     |     |      ");
                Console.WriteLine("  {0}  |  {1}  |  {2}", sarr[7], sarr[8], sarr[9]);
                Console.WriteLine("     |     |      ");
            }
            //checks if someone has three in a row

            static int Checkwin(char[] sarr)
            {

                //horizontal wins
                if (sarr[1] == sarr[2] && sarr[2] == sarr[3])
                {
                    return 1;
                }
                else if (sarr[4] == sarr[5] && sarr[5] == sarr[6])
                {
                    return 1;
                }
                else if (sarr[7] == sarr[8] && sarr[8] == sarr[9])
                {
                    return 1;
                }

                //vertical wins
                if (sarr[1] == sarr[4] && sarr[4] == sarr[7])
                {
                    return 1;
                }
                else if (sarr[2] == sarr[5] && sarr[5] == sarr[8])
                {
                    return 1;
                }
                else if (sarr[3] == sarr[6] && sarr[6] == sarr[9])
                {
                    return 1;
                }
                //diagonal wins
                if (sarr[1] == sarr[5] && sarr[5] == sarr[9])
                {
                    return 1;
                }
                else if (sarr[3] == sarr[5] && sarr[5] == sarr[7])
                {
                    return 1;
                }
                if (isFullBoard(sarr))
                {
                    return -1;
                }
                else
                {
                    return 0;
                }

            }
            static bool isFullBoard(char[] sarr)
            {
                bool isFullBoard = true;
                for (int i = 1; i < sarr.Length; i++)
                {
                    if (sarr[i] != 'O' && sarr[i] != 'X')
                    {
                        isFullBoard = false;
                        break;
                    }
                }
                return isFullBoard;

            }

        }
    }
}
